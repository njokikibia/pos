package dev.habibzad.brewscape;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CornerCafeApp {

    public static void main(String[] args) {
        SpringApplication.run(CornerCafeApp.class, args);
    }

}
